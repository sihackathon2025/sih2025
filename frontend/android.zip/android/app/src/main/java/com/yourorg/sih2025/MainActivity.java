package com.yourorg.sih2025;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
